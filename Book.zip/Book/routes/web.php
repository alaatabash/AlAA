<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| This file is where you may define all of the routes that are handled
| by your application. Just tell Laravel the URIs it should respond
| to using a Closure or controller method. Build something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
//Sections
Route::get('/show','SectionCont@index');
Route::post('/insert','SectionCont@insertSection');
Route::get('/delete/{id}/delete/','SectionCont@deleteSection'); 

Route::get('/updatesection/{id}/update','SectionCont@updateSection');
Route::post('/upsection','SectionCont@upSection'); 
Route::post('/re/{id}/re','SectionCont@softdelete ');
//Books
Route::get('/library/{id}/','BookCont@indexBook');
Route::post('/insertbook','BookCont@insertBook'); 
Route::get('/DeleteB/{id}/','BookCont@deleteBook'); 
Route::post('/updateB/{id}/updateB','BookCont@upBook');
 
//Authors