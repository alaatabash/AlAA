@extends('master')
@section('content')
<br>
<div class="panel panel-default">
  <div class="panel-heading">Panel Heading</div>
  <div class="panel-body">
  <h1>Update {{$image->section_name}} Sections</h1>
  <form action="/upsection" method="post" enctype="multipart/form-data">
  {{csrf_field()}}
  	<div class="form-group">
  	<input type="hidden" name="id" value="{{$image->id}}">
    <input type="text" name="image" value="{{$image->name_image}}">
  		<label>name Section</label>
  		<input type="text" name="nameSection" value="{{$image->section_name}}" class="form-control">
  	</div>
  	<div class="form-group" >
  		<label>Total Book</label>
  		<input type="text" name="total" value="{{$image->book_total}}" class="form-control">
  	</div>
  	<div class="form-group" >
  		<label>Upload image</label>

  		<input type="file" name="file" class="form-control ">
  		<img src="{{asset('uploads/'.$image->name_image)}}" width="200px" height="200px">

  	</div>
  	<div class="form-group">
  		 
  		<input type="submit" name="submit" value="Update" class="btn btn-info btn-lg">
  	</div>
  </form>
  </div>
</div>

@stop