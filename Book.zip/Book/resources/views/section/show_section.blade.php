@extends('master')
@section('content')
<br>
<div class="panel panel-default">
  <div class="panel-heading">Panel Heading</div>
  <div class="panel-body">
  <h1>Create New Sections</h1>
 <form method="post" action="/insert" enctype="multipart/form-data">
 {{csrf_field()}}
  	<div> 
  	<label>Enter the name of the section :</label>
  		<input type="text" name="sectionname">
  	</div>
  	<div>
  		<label>upload iamge </label>
  		<input type="file" name="upload" value="choose image">

  	</div>
  		<div>
  		 
  		<input type="submit" name="Send" value="Send" class="btn btn-info">

  	</div>
 </form> 
 <div class="panel-body"> 
 <table class="table">
 	<tr>
 		<th>Section Name</th>
 		<th>Total book</th>
 		<th><a href="#">Update</a></th>
 		<th><a href="#" >Delete</a></th>
 		<th><a href="#"  >Show</a></th> 
    <th></th>
 	</tr>
 	@foreach($section as $row)
     @if($row->trashed()) 
    <tr style="background-color:'#ff0000' "></tr>
    @else 
 <tr style="background-color:'#ffffff' "></tr>
    @endif
 	<tr>  
 	    
 	    <input type="hidden" value="{{$row->id}}" name="id"> 
 		<td><input type="text" value="{{$row->section_name}}" name="nameSection"></td>
 		<td >  <span class="label label-default">{{$row->book_total}}</span> </td>
 		 
 		<td><a href="/updatesection/{{$row->id}}/update" class="btn btn-success" 
 		>Update</a></td>
 		<!-- data-toggle="modal" data-target="#myModal" -->

 		<td><a href="/delete/{{$row->id}}/delete/" class="btn btn-danger">Delete</a></td>
 		<td><a href="library/{{$row->id}}" class="btn btn-default">Show</a></td>   
    @if($row->trashed())
    <td>
    <!--   <form action="/restores/{{$row->id}}/restores" method="post">
      {{csrf_field()}}
        <input type="submit" name="submit" value="restore">
      }
      }
      </form> -->
<a href="/re/{{$row->id}}/re" name="submit" class="btn btn-default">restore</a>
    </td>
    @endif

 	</tr>
 
   @endforeach
 </table>

 </div>
  </div>
</div>

// 
<!-- Large modal -->
<div class="container">
 

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <form action="/updatesection" method="post" enctype="multipart/form-data">
        {{csrf_field()}}
        <div class="modal-body">
         
           
         	<input type="text" name="namesection">
         	<input type="text" name="total">
         	<input type="file" name="upload">
         	
         
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
           
            <input type="submit"class="btn btn-success" data-dismiss="modal" name="submit" value="Update">
        </div>
        </form>
      </div>
      
    </div>
  </div>
  
</div>

<!-- Small modal -->

//
@stop
