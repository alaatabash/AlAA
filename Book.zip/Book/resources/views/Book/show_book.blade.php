@extends('master')
@section('content')
<br>
 
<div class="panel panel-default">
  <div class="panel-heading">Panel Heading</div>
  <div class="panel-body">
  <h1>Create {{$section->section_name}} Book</h1>
  <form method="post" action="/insertbook">
  {{csrf_field()}}
  	<div>  
     <input type="hidden" name="section_id" value="{{$section->id}}">
  	<label>Book Title:</label>
  		<input type="text" name="BookTitle" >
  	</div>
  	<div> 
  	<label>Book Edition:</label>
  		<input type="text" name="BookEdition">
  	</div>
  	<div> 
  	<label>Book Publiation:</label>
  		<input type="date" name="BookPubliation">
  	</div>
  	<div>
  	<label>Book Description :</label>
  		<input type="text" name="BookDescription">
  	</div> 
    <div>
    <label>Authors :</label>
      <input type="text" name="authors">
    </div> 
  	<div>
  		 
  		<input type="submit" name="Send" value="Send" class="btn btn-info">

  	</div>
 </form> 
  

  
 
 <div class="panel-body">  
  <table class="table">
  	<tr>
  		<th> Book Title</th>
  		<th> Book Edition</th>
      <th> Book Description</th>
  		<th> Authors</th>
      <th><a href="#">Update</a></th>
  		<th><a href="#">Delete</a></th>
  	</tr>  
    @foreach($all_Book as $row)
  		<tr>
        <form action="/updateB/{{$row->id}}/updateB" method="post">
      {{csrf_field()}}
  		<th> <input type="text" name="BookTitle" value="{{$row->book_title}}"  ></th>
  		<th> <input type="text" name="BookEdition" value="{{$row->book_edition}}"  > </th>
      <th> <textarea type="text" name="BookDescription"  >{{$row->book_description}}</textarea></th>
    <th> <input type="date" name="BookPubliation" value="{{$row->book_publication}}"  > </th>
    <th><span class="label  label-info">Book Publiation</span> </th>
  		 
    
   		<td> 
  
        <input type="hidden" name="section_id" value="{{$section->id}}"> <input type="submit" name="submit" value="Update" class="btn btn-success">

      </form>
         
       <!--   <a href=" /updateB/{{$row->id}}/updateB" >Update</a> -->

 
     </td>

  		<td>
      <form action="/DeleteB/{{$row->id}}/" method="get">
      {{csrf_field()}}
        <input type="hidden" name="section_id" value="{{$section->id}}"> <input type="submit" name="submit" value="Delete" class="btn btn-danger">

      </form>
       </td>
  	</tr> 
    @endforeach
  </table>
 

 
</div>
  </div>
</div> 
@stop