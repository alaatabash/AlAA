@extends('master')
@section('content')
<br>
<div class="panel panel-default">
  <div class="panel-heading">Panel Heading</div>
  <div class="panel-body">
  <h1>Update {{$book->book_title}} Sections</h1>
  <form action="/upB" method="post"  >
  {{csrf_field()}}
    <div class="form-group">
    <input type="hidden" name="id" value="{{$book->id}}">
 
      <label>Book Title</label>
     <input type="text" name="BookTitle" value="{{$book->book_title}}" class="form-control">
    </div>

  	<div class="form-group">
   
    
  		<label>Book Edition</label>
  		<input type="text" name="BookEdition" value="{{$book->book_edition}}" class="form-control">
  	</div>
  	<div class="form-group" >
  		<label>Book Publication</label>
  		<input type="text" name="BookPubliation" value="{{$book->book_publication}}" class="form-control">
  	</div>
  	<div class="form-group" >
  		<label>Book Description </label>

  		<input type="text" name="BookDescription" value="{{$book->book_description}}" class="form-control ">
  	 

  	</div>
  	<div class="form-group">
  		 
  		<input type="submit" name="submit" value="Update" class="btn btn-info btn-lg">
  	</div>
  </form>
  </div>
</div>

@stop