<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    public $table="books";
    public function authors()
    {
    	return $this->belongsToMany('App\Author','books_authors_relationship');
    }
     public function sections()
    {
    	return $this->belongsTo('App\Section');
    }
}
