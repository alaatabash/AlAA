<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Section extends Model
{  
	 use SoftDeletes;
	 
    protected $dates = ['deleted_at'];
	public $table="sections";
  public function books( )
  {
  	return $this->hasmany('App\Book');
  }
}
