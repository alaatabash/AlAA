<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Section;
use Illuminate\Support\Facades\Input;
use File;
use DB;

class SectionCont extends Controller
{
    public function index()
    {
         $section=Section::withTrashed()->get();
     	return view('section.show_section',compact('section',$section));
    }   

     public function insertSection(Request $Request)
     { 
      $file=Input::file('upload'); 
       $name=$file->getClientOriginalName();
     	$full=$file->move('uploads/',$name);
      $section=new Section();
       $section->section_name= $Request->sectionname;
        $section->book_total='0';
        $section->name_image=$name;
        $section->save();
        return back();

     }
     public function deleteSection($id)
      {
       $image=Section::find($id);
       $i=File::delete('uploads/'.$image->name_image);
       $image->delete();
       return back();
      }  
         

          public function updateSection($id )
          { 
          	$image=Section::find($id); 
          	return view('section.update',compact('image',$image));
          
          }
          public function upSection()
          {
          	 $id=Input::get('id');
          	  
          	 $names=Input::get('image');
          	 $total=Input::get('total');
            File::delete('uploads/'.$names);
          	 if(Input::file('file')) {
          	 	 
          	 	   
               $file=Input::file('file'); 
            $name=$file->getClientOriginalName();
          $full= $file->move('uploads/',$name );
                
               
             $arrayName = array(
                'section_name' =>Input::get('nameSection') ,
                'book_total' =>Input::get('total') ,
                 'name_image'=>   $name
                );
             
             
      $s =DB::table('sections')->where('id',$id)->update($arrayName);
          	 	
          	 }
          	  return redirect('/show');
          	

          }
           public function softdelete($id)
           {
              $section=Section::onlyTrashed()->find($id);
              $section->restore();
               return redirect('/show');
           }


}
