<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Section;
use App\Book;
use DB;
class BookCont extends Controller
{
    public function indexBook($id)
    {  
    	$section=Section::find($id);
    	$all_Book=$section->books;
    	return view('Book.show_book',
    		compact('section',$section,'all_Book',$all_Book));
    }

    public function insertBook(Request $Request)
    {
      $book=new Book(); 
      $book_title=$Request->BookTitle;
      $book_edition=$Request->BookEdition;
      $book_publication=$Request->BookPubliation;	 
      $book_description =$Request->BookDescription;
      $section_id=$Request->section_id; 

       $book->book_title=$book_title;
       $book->book_edition=$book_edition;
       $book->book_publication=$book_publication;
       $book->book_description=$book_description;
       $book->section_id=$section_id;
       $book->save();
      // DB::table('books')
      // ->insert([
      // 	'book_title'=>$book_title,
      // 	'book_edition'=>$book_edition,
      // 	'book_publication'=>$book_publication,
      // 	'book_description'=>$book_description,
      // 	'section_id'=>$section_id,
      // 	]);
      return redirect('/library/'.$section_id);  
      // $book->save();
      // return back();
    }

    public function deleteBook($id,Request $Request)
    {
    	$section_id=$Request->section_id; 
    	$book=Book::find($id);
    	$book->delete();
    	return redirect('/library/'.$section_id);  
    } 
    // public function upBook($id)
    // { 
    //   $section=new Section();
    //   $book=Book::find($id); 
    //   return view('Book.updateB',compact('section',$section,'book',$book,));

    // } 
     public function upBook($id,Request $Request)
    {
       
      $book_title=$Request->BookTitle;
      $book_edition=$Request->BookEdition;
      $book_publication=$Request->BookPubliation;  
      $book_description =$Request->BookDescription; 
      $id =$Request->id;
       $section_id=$Request->section_id;
      $book=Book::find($id); 

       $book->book_title=$book_title;
       $book->book_edition=$book_edition;
       $book->book_publication=$book_publication;
       $book->book_description=$book_description;
     
       $book->save();
        return redirect('/library/'. $section_id); 
    }
}
