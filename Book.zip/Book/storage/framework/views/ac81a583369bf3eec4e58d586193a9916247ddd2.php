<?php $__env->startSection('content'); ?>
<br>
<div class="panel panel-default">
  <div class="panel-heading">Panel Heading</div>
  <div class="panel-body">
  <h1>Create New Sections</h1>
 <form method="post" action="/insert" enctype="multipart/form-data">
 <?php echo e(csrf_field()); ?>

  	<div> 
  	<label>Enter the name of the section :</label>
  		<input type="text" name="sectionname">
  	</div>
  	<div>
  		<label>upload iamge </label>
  		<input type="file" name="upload" value="choose image">

  	</div>
  		<div>
  		 
  		<input type="submit" name="Send" value="Send" class="btn btn-info">

  	</div>
 </form> 
 <div class="panel-body"> 
 <table class="table">
 	<tr>
 		<th>Section Name</th>
 		<th>Total book</th>
 		<th><a href="#">Update</a></th>
 		<th><a href="#" >Delete</a></th>
 		<th><a href="#"  >Show</a></th> 
    <th></th>
 	</tr>
 	<?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
     <?php if($row->trashed()): ?> 
    <tr style="background-color:'#ff0000' "></tr>
    <?php else: ?> 
 <tr style="background-color:'#ffffff' "></tr>
    <?php endif; ?>
 	<tr>  
 	    
 	    <input type="hidden" value="<?php echo e($row->id); ?>" name="id"> 
 		<td><input type="text" value="<?php echo e($row->section_name); ?>" name="nameSection"></td>
 		<td >  <span class="label label-default"><?php echo e($row->book_total); ?></span> </td>
 		 
 		<td><a href="/updatesection/<?php echo e($row->id); ?>/update" class="btn btn-success" 
 		>Update</a></td>
 		<!-- data-toggle="modal" data-target="#myModal" -->

 		<td><a href="/delete/<?php echo e($row->id); ?>/delete/" class="btn btn-danger">Delete</a></td>
 		<td><a href="library/<?php echo e($row->id); ?>" class="btn btn-default">Show</a></td>   
    <?php if($row->trashed()): ?>
    <td>
    <!--   <form action="/restores/<?php echo e($row->id); ?>/restores" method="post">
      <?php echo e(csrf_field()); ?>

        <input type="submit" name="submit" value="restore">
      }
      }
      </form> -->
<a href="/re/<?php echo e($row->id); ?>/re" name="submit" class="btn btn-default">restore</a>
    </td>
    <?php endif; ?>

 	</tr>
 
   <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
 </table>

 </div>
  </div>
</div>

// 
<!-- Large modal -->
<div class="container">
 

  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <form action="/updatesection" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="modal-body">
         
           
         	<input type="text" name="namesection">
         	<input type="text" name="total">
         	<input type="file" name="upload">
         	
         
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
           
            <input type="submit"class="btn btn-success" data-dismiss="modal" name="submit" value="Update">
        </div>
        </form>
      </div>
      
    </div>
  </div>
  
</div>

<!-- Small modal -->

//
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>