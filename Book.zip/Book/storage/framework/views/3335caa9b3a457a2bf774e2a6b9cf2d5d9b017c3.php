<!DOCTYPE html>
<html>
<head>
	<title>admin</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
   <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<style type="text/css">
		 
		.jumbotron{ 
			margin: 0px;
			height: 200px;
		 padding-top: 0px;

		 }
     #table{ 
     margin-left: 150px }
         
	</style>
</head>
<body>
<div class="jumbotron">
<table  width="100%" id="table">
    <tr>
    <td>
    <h2>BookStore!!</h2>
    <h3> My name is alaa tabash</h3>
    <h3> My name is alaa tabash</h3>
    <h4> My libary includ Author and Section and Book</h4>
    </td>
    <td> <ul>
    <li><a href="/show">Home</a></li>
    <li><a href="#">alaa tabash</a></li>
    <li> date:<?php echo date('l jS \of F Y h:i:s A')?></li>
    </ul></td>
    </tr>
</table>
  

</div>
<div class="container">

	<?php echo $__env->yieldContent('content'); ?>
 
</div>
</body>
</html>

 