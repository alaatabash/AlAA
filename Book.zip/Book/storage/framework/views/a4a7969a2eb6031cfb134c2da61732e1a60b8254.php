<?php $__env->startSection('content'); ?>
<br>
<div class="panel panel-default">
  <div class="panel-heading">Panel Heading</div>
  <div class="panel-body">
  <h1>Update <?php echo e($book->book_title); ?> Sections</h1>
  <form action="/upB" method="post"  >
  <?php echo e(csrf_field()); ?>

    <div class="form-group">
    <input type="hidden" name="id" value="<?php echo e($book->id); ?>">
 
      <label>Book Title</label>
     <input type="text" name="BookTitle" value="<?php echo e($book->book_title); ?>" class="form-control">
    </div>

  	<div class="form-group">
   
    
  		<label>Book Edition</label>
  		<input type="text" name="BookEdition" value="<?php echo e($book->book_edition); ?>" class="form-control">
  	</div>
  	<div class="form-group" >
  		<label>Book Publication</label>
  		<input type="text" name="BookPubliation" value="<?php echo e($book->book_publication); ?>" class="form-control">
  	</div>
  	<div class="form-group" >
  		<label>Book Description </label>

  		<input type="text" name="BookDescription" value="<?php echo e($book->book_description); ?>" class="form-control ">
  	 

  	</div>
  	<div class="form-group">
  		 
  		<input type="submit" name="submit" value="Update" class="btn btn-info btn-lg">
  	</div>
  </form>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>